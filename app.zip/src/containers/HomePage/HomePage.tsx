const HomePage = () => {
  return <div>HomePagee</div>;
};

export default HomePage;

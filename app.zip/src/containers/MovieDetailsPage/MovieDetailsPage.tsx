const MovieDetailsPage = () => {
  return <div>Movie Details Page</div>;
};

export default MovieDetailsPage;

interface Props {
  title: string;
}

const Suggestion = ({ title }: Props) => {
  return <div>{title}</div>;
};

export default Suggestion;

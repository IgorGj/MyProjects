import { DataType } from "../MovieList/types";
import { Link } from "react-router-dom";

const MovieCard = ({ Poster, Title, imdbID }: DataType) => {
  return (
    <Link to={`/details/${imdbID}`}>
      <div className="border">
        <img src={Poster} alt="title" />
        <h1>{Title}</h1>
      </div>
    </Link>
  );
};

export default MovieCard;

import { HeaderProps } from "../types";
import { DebounceInput } from "react-debounce-input";

const Search = ({ setSearchTerm }: HeaderProps) => {
  return (
    <div>
      <DebounceInput
        minLength={2}
        debounceTimeout={500}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
    </div>
  );
};

export default Search;

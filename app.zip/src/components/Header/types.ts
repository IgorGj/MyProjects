export interface HeaderProps {
  setSearchTerm: (searchTerm: string) => void;
}

import Suggestion from "../Suggestion/Suggestion";

interface Props {
  data: string[];
}

const SuggestionList = ({ data }: Props) => {
  return (
    <div>
      {data.map((title) => (
        <Suggestion title={title} />
      ))}
    </div>
  );
};

export default SuggestionList;
